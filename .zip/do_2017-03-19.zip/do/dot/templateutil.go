// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"errors"
	"strings"
)

const (
	tmplL = "{{"
	tmplR = "}}"
	commL = tmplL + "/*"
	commR = "*/" + tmplR
)

// helper to extract text bracketed by left & right
func Extract(text, left, right string) (string, error) {
	l, r := len(left), len(right)
	var s, t string

	if l < 1 {
		return s, errors.New("Left delimiter must not be empty")
	}
	if r < 1 {
		return s, errors.New("Right delimiter must not be empty")
	}

	t = text
	// for n := 1; n < 10000; n++ {
	for {

		if t == "" {
			return s, nil
		}
		i := strings.Index(t, left)
		if i < 0 {
			return s, nil
		}
		t = string(t[(i + l):])
		//	println("t:", t)
		j := strings.Index(t, right)
		if j < 0 {
			return s, errors.New("No matching right delimiter")
		}
		s = s + string(t[:j])
		//	println("s:", s)
		t = string(t[(j + r):]) // len(t)-j-r-1
		//	println("t:", t)
	}
	// return s, errors.New("Too many loops")
}
