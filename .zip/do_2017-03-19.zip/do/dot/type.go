// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

// Types handled by this package
const (
	Dirs Type = "Dirs"
	Path Type = "Path"

	FilePath Type = "FilePath"
	FileInfo Type = "FileInfo"

	Meta Type = "Meta" // parsed MetaTemplate
	Tmpl Type = "Tmpl" // parsed Template(s)
)

// Type represents a type handled by this package
type Type string

func (t Type) Id() string {
	return t.String() + ":"
}

func (t Type) String() string {
	return string(t)
}
