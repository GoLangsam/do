// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// package ssr implements Stringer - a convenience type
package ssr // fmt.Stringer for a string

// Note: this interface is exposed for godoc - only ;-)
//
// I love to be friendly - thus: I give You a simple API!
//  to accept/convert any text string:
//   s := ssr.Stringer(text string)
//  to return the text as string:
//   t := s.String()
//
type Friendly interface {
	String() string // fmt.Stringer
}

// Stringer helps to accept any string and use it as fmt.Stringer (or interface{})
type Stringer string

// implement fmt.Stringer
func (s Stringer) String() string {
	return string(s)
}
