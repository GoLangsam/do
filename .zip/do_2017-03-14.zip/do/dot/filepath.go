﻿package dot

import (
	"os"
	"path/filepath"
)

/*
func dotFilePathTag(d Dot, tag string) Dot {
	c := lookup(d, FilePath.Id())
	c.Tag(tag)
	return c
}
*/

func dotFileInfoTag(d Dot, tag string) Dot {
	c := lookup(d, FileInfo.Id())
	c.Tag(tag)
	return c
}

// Glob with pattern from d.K and add results below FilePath
func AddFilePathGlob(d Dot) Dot {
	myName := "AddGlob"

	arg := filepath.FromSlash(d.String())

	m, err := filepath.Glob(arg)
	if d.SeeError(myName, d.String(), err) { return d }
	var res []string
	for _, f := range m {
		res = append(res, filepath.ToSlash(filepath.Clean(f)))
	}
	d.UnlockedAdd(FilePath.Id(), res...)
	return d
}

/*
WalkFunc is the type of the function called for each file or directory
visited by Walk. The path argument contains the argument to Walk as a
prefix; that is, if Walk is called with "dir", which is a directory
containing the file "a", the walk function will be called with argument
"dir/a". The info argument is the os.FileInfo for the named path.

If there was a problem walking to the file or directory named by path, the
incoming error will describe the problem and the function can decide how to
handle that error (and Walk will not descend into that directory). If an
error is returned, processing stops. The sole exception is when the function

returns the special value SkipDir. If the function returns SkipDir when
invoked on a directory, Walk skips the directory's contents entirely. If the

function returns SkipDir when invoked on a non-directory file, Walk skips
the remaining files in the containing directory.
*/

func addFileInfoWF (d Dot, myName string) filepath.WalkFunc {

	// define walkFunc
	var walkFunc filepath.WalkFunc = func(path string, info os.FileInfo, err error) error {
		c := lookup(d, path)
		c.Tag(info)
		return nil
	}
	return walkFunc
}

/*
Walk walks the file tree rooted at root, calling walkFn for each file or
directory in the tree, including root. All errors that arise visiting files
and directories are filtered by walkFn. The files are walked in lexical
order, which makes the output deterministic but means that for very large
directories Walk can be inefficient. Walk does not follow symbolic links.
*/

// Walk down path from d.K and add results below FileInfo: Key = FilePath, Val = os.FileInfo
//
// Must be called from type-node! (d.K == FilePath.Id)
func AddFileInfoWalk(d Dot) Dot {
	myName := "AddFileInfo"

	arg := filepath.FromSlash(d.String())	// path to walk
	c := lookup(d, FileInfo.Id())		// where to add
	filepath.Walk(arg, addFileInfoWF(c, myName))

	return d
}
