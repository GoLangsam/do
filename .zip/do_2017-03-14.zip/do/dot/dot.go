﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"do/ami"
	"fmt"
)

type Dot interface {
	//	Lock()	 // sync.Locker
	//	Unlock()	// sync.Locker

	String() string // fmt.Stringer

	// from Tag
	//	K() string	// no need - we use String()
	V() interface{}		// TODO - don't know how to get the content as string!
	Tag(val interface{})

	// from StringMap
	UnlockedGet(key string) (interface{}, bool)
	UnlockedAdd(key string, val ...string) (interface{}, bool)

	SeeError(myName, myThing string, err error) bool
	SeeNotOk(myName, myThing string, ok bool, complain string) bool
}

// Dot-Types handled by this package
const (
	FilePath DotType = "FilePath"
	FileInfo DotType = "FileInfo"
)

// DotType represents a type handled by this package
type DotType string

func (t DotType) Id() string {
	return t.String() + ":"
}

func (t DotType) String() string {
	return string(t)
}

// helpers

// access child

func lookup(d Dot, key string) Dot {
	any, ok := d.UnlockedGet(key)
	if d.SeeNotOk("UnlockedGet for key=", key, ok, " returned false?!?") {
		panic("UnlockedGet for key=" + key + " returned false?!?")
	}
	c, ok := any.(Dot)
	if d.SeeNotOk("UnlockedGet", key, ok, "What? No dot returned?!?") {
		panic("UnlockedGet: No dot returned for key=" + key + "?!?")
	}
	return c
}

// Value-handlers

func vtoString(d Dot, myName string) (string, bool) {
	if d.V() == nil {
		println("NIL!!!")
	}
	println(ami.TypeKind(d.V))
	println(ami.TypeName(d.V))
	println(ami.TypeString(d.V))

	value, ok := d.V().(fmt.Stringer) // is V a string?
	println("is V a string?: ", ok)
	if d.SeeNotOk(myName, d.String(), ok, "my Value must be a string!") {
		return "", false
	}
	return value.String(), true
}

func vtoNonEmptyString(d Dot, myName string) (string, bool) {
	if value, ok := vtoString(d, myName); !ok { // is V a string?
		return "", false
	} else {
		if value == "" {
			d.SeeNotOk(myName, d.String(), false, "my Value must not be empty!")
			return "", false
		} else {
			return value, true
		}
	}
}
