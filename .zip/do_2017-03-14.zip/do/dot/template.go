﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"text/template"
)

type TemplateFriendly interface {
	Lock()   // via sync.Mutex
	Unlock() // via sync.Mutex
}

// var _ TemplateFriendly = New("Interface satisfied? :-)")

var _ = template.New("Don't cry!")

/*
	tc, err := Extract(tt.V(), commL, commR)
	if err != nil {
		fmt.Println(err)
	}

	ct := template.New("/").Funcs(funcs).Delims(tmplL, tmplR)
	if ct, err := ct.Parse(tc); err == nil {
		//fmt.Println(t)
		fmt.Println("Meta:")
		ct.Execute(os.Stdout, d)
	} else {
		fmt.Println(err)
	}
	_ = ct

	t := template.New("/").Funcs(funcs).Delims(tmplL, tmplR)
	if t, err := t.Parse(tt); err == nil {
		//fmt.Println(t)
		fmt.Println("Tmpl:")
		t.Execute(os.Stdout, d)
	} else {
		fmt.Println(err)
	}
	_ = t

*/
