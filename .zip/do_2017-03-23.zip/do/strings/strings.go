// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package ds // do strings

import (
	"errors"
	"strings"
)

/*
func Index(s, sep string) int
    Index returns the index of the first instance of sep in s, or -1 if sep is
    not present in s.
*/

// Extract all text bracketed by left & right
func Extract(text, left, right string) (string, error) {
	l, r := len(left), len(right)
	var s, t string

	if l < 1 {
		return s, errors.New("Left delimiter must not be empty")
	}
	if r < 1 {
		return s, errors.New("Right delimiter must not be empty")
	}

	t = text
	// for n := 1; n < 10000; n++ {
	for {

		if t == "" {
			return s, nil
		}
		i := strings.Index(t, left)
		if i < 0 {
			return s, nil
		}
		t = string(t[(i + l):])
		//	println("t:", t)
		j := strings.Index(t, right)
		if j < 0 {
			return s, errors.New("No matching right delimiter")
		}
		s = s + string(t[:j])
		//	println("s:", s)
		t = string(t[(j + r):]) // len(t)-j-r-1
		//	println("t:", t)
	}
	// return s, errors.New("Too many loops")
}

/*
func TrimLeft(s string, cutset string) string
	TrimLeft returns a slice of the string s with all leading Unicode code
	points contained in cutset removed.

func TrimRight(s string, cutset string) string
	TrimRight returns a slice of the string s, with all trailing Unicode code
	points contained in cutset removed.
*/

// UnBracket returns what it found between bo & bc
func UnBracket(in, bo, bc string) string {
	return strings.TrimLeft(strings.TrimRight(in, bc), bo)
}
