// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"bytes"
	"errors"
	"strings"

	"do/ami"
	"do/dot/funcs"
	ds "do/strings"
	"text/template"
)

type TemplateFriendly interface {
	Lock()   // via sync.Mutex
	Unlock() // via sync.Mutex
}

// var _ TemplateFriendly = New("Interface satisfied? :-)")

var _ = template.New("Don't cry!")
var _ = funcs.Funcs //Don't cry!

func IsTemplate(v interface{}) bool {
	switch v.(type) {
	case template.Template:
		return true
	default:
		return false
	}
}

func ToTemplate(v interface{}) (*template.Template, error) {
	switch v := v.(type) {
	case *template.Template:
		return v, nil
	default:
		return nil, errors.New("Expected 'Template' - got '" + ami.TypeName(v) + "'!")
	}
}

const (
	tmplL = "{{"
	tmplR = "}}"
	commL = tmplL + "/*-" // restrict comment to "{{/*-" for Meta-Comments
	commR = "-*/" + tmplR // restrict comment to "-*/}}" for Meta-Comments
)

var (
	TmplFileExt string = ".tmpl" // template file extension (with dot)
)

// Parse Template ===============================================

/*
func New(name string) *Template
    New allocates a new, undefined template with the given name.
*/

// NewTemplate allocates a new, undefined template with the given name.
func NewTemplate(name string) *template.Template {
	return template.New(name).Funcs(funcs.Funcs).Delims(tmplL, tmplR)
}

// Parse(text string) (*Template, error)
func parseNewTemplate(tar Dot, myName, myId, srcName, data string) Dot {
	tmpl, err := NewTemplate(srcName).Parse(data)
	if !tar.SeeError(myName, srcName, err) {
		to := lookupDot(tar, myId)
		to = lookupDot(to, srcName) // tmpl.Name())
		to.Tag(tmpl)
	}
	return tar
}

// Parse Comments ===============================================

// MetaParse parses the comments as new template named srcName and Tag's it into tar/":Meta:"/Name()
func MetaParse(tar Dot, srcName, data string) Dot {
	myName := "MetaParse"

	meta, err := ds.Extract(data, commL, commR)
	if tar.SeeError(myName+"Extract", srcName, err) {
		return tar
	}
	return parseNewTemplate(tar, myName, Meta.Id(), srcName, meta)
}

func DoMetaParse(src, tar Dot) Dot {
	MetaParse(tar, src.String(), v(src))
	return src
}

func ExecMetaParse(d Dot) Dot {
	return DoMetaParse(d, d)
}

// Parse Template ===============================================

// TmplParse parses the data as template and Tag's it into "Tmpl:"/Name()
func TmplParse(tar Dot, srcName, data string) Dot {
	myName := "TmplParse"

	return parseNewTemplate(tar, myName, Tmpl.Id(), srcName, data)
}

func DoTmplParse(src, tar Dot) Dot {
	TmplParse(tar, src.String(), v(src))
	return src
}

func ExecTmplParse(d Dot) Dot {
	return DoTmplParse(d, d)
}

// Execute ===============================================

// func (t *Template) Execute(wr io.Writer, data interface{}) error
func TmplExecute(tar Dot, myName, myId, srcName string, tmpl *template.Template, data Dot) Dot {
	var buf bytes.Buffer
	tmpl.Execute(&buf, data)
	exetxt := buf.String()
	buf.Reset()

	fileName := strings.TrimSuffix(srcName, TmplFileExt)
	tmpl, err := NewTemplate("FileName").Parse(fileName)
	if !tar.SeeError(myName, srcName, err) {
		tmpl.Execute(&buf, data)
		fileName = buf.String()
		buf.Reset()
	}

	to := lookupDot(tar, myId)
	to = lookupDot(to, fileName)
	to.Tag(exetxt)

	return tar
}

func DoTmplExecute(src, tar, data Dot) Dot {
	myName := "DoTmplExecute"
	tmpl, err := ToTemplate(src.GetV())
	if !tar.SeeError(myName, src.String(), err) {
		TmplExecute(tar, myName, Exec.Id(), src.String(), tmpl, data)
	}
	return src
}

func ExecTmplExecute(d, data Dot) Dot {
	return DoTmplExecute(d, d, data)
}
