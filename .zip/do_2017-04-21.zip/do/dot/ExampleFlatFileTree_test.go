﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot_test

import (
	"container/ccsafe/dot"
	"do/dot"
)

func ExampleFlatFileTree() {
	var FileTree = dot.New("../..") // Dot
	// do.DoReadDir(FileTree, FileTree.G(do.FileInfo.Id())) //
	do.ExecReadAllDirs(FileTree) //
	FileTree = FileTree.PrintTree(">>")
}
