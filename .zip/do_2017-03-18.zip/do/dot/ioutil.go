package dot

import (
	"io/ioutil"
	"os"
	"path/filepath"
)

var Perm os.FileMode = 0644 // default os.FileMode

// func ioutil.ReadFile(filename string) ([]byte, error)
func TagReadFile(tar Dot, filename string) Dot {
	myName := "TagReadFile"

	filename = filepath.FromSlash(filename)
	data, err := ioutil.ReadFile(filename)

	if !tar.SeeError(myName, filename, err) {
		tar.Tag(string(data))
	}
	return tar
}

func DoTagReadFile(src, tar Dot) Dot {
	TagReadFile(tar, src.String())
	return src
}

func ExecTagReadFile(d Dot) Dot {
	TagReadFile(d, d.String())
	return d
}

// func ioutil.WriteFile(filename string, data []byte, perm os.FileMode) error
func WriteFileData(tar Dot, filename string, data []byte) Dot {
	myName := "WriteFileData"

	err := ioutil.WriteFile(filename, data, Perm)
	_ = tar.SeeError(myName, filename+" "+tar.String(), err)
	return tar

}

// func ioutil.WriteFile(filename string, data []byte, perm os.FileMode) error
func WriteFileFromValue(tar Dot, filename string) Dot {
	myName := "DoWriteFile"

	value, ok := vtoNonEmptyString(tar, myName) // is V a string?
	if !ok {
		return tar
	}
	data := []byte(value)

	return WriteFileData(tar, frSlash(filename), data)
}

func DoWriteFileFromValue(src, tar Dot) Dot {
	WriteFileFromValue(tar, src.String())
	return src
}

func ExecWriteFileFromValue(d Dot) Dot {
	WriteFileFromValue(d, d.String())
	return d
}

// func ioutil.ReadDir(dirname string) ([]os.FileInfo, error)
func ReadDir(tar Dot, dirname string) Dot {
	myName := "ReadDir"

	dirname = frSlash(dirname)

	dirs, err := ioutil.ReadDir(dirname)
	if tar.SeeError(myName, dirname, err) {
		return tar
	}

	for _, dir := range dirs {
		lookupDot(tar, dir.Name()).Tag(dir)
	}
	return tar
}

func DoReadDir(src, tar Dot) Dot {
	ReadDir(tar, src.String())
	return src
}

func ExecReadDir(d Dot) Dot {
	ReadDir(d, d.String())
	return d
}

/*
func TempDir(dir, prefix string) (name string, err error)
func TempFile(dir, prefix string) (f *os.File, err error)
*/
