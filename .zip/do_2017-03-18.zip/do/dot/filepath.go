﻿package dot

import (
	"os"
	"path/filepath"
)

func frSlash(path string) string {
	return filepath.Clean(filepath.FromSlash(path))
}

func toSlash(path string) string {
	return filepath.ToSlash(filepath.Clean(path))
}

// filePathGlob
func FilePathGlob(tar Dot, path string) Dot {
	myName := "Glob"

	m, err := filepath.Glob(frSlash(path))
	if tar.SeeError(myName, path, err) {
		return tar
	}

	var res []string
	for _, f := range m {
		res = append(res, toSlash(f))
	}

	to := lookupDot(tar, myName+":")
	to.UnlockedAdd(Path.Id(), path)
	to.UnlockedAdd(FilePath.Id(), res...)
	return tar
}

// Glob with pattern from src and add results to tar below "FilePath:"
func DoFilePathGlob(src, tar Dot) Dot {
	FilePathGlob(tar, src.String())
	return src
}

// Glob with pattern from src and add results to tar below "FilePath:"
func ExecFilePathGlob(d Dot) Dot {
	FilePathGlob(d, d.String())
	return d
}

/*
WalkFunc is the type of the function called for each file or directory
visited by Walk. The path argument contains the argument to Walk as a
prefix; that is, if Walk is called with "dir", which is a directory
containing the file "a", the walk function will be called with argument
"dir/a". The info argument is the os.FileInfo for the named filepath.

If there was a problem walking to the file or directory named by path, the
incoming error will describe the problem and the function can decide how to
handle that error (and Walk will not descend into that directory). If an
error is returned, processing stops. The sole exception is when the function

returns the special value SkipDir. If the function returns SkipDir when
invoked on a directory, Walk skips the directory's contents entirely. If the

function returns SkipDir when invoked on a non-directory file, Walk skips
the remaining files in the containing directory.
*/

func allInfoWF(tar Dot, myName string) filepath.WalkFunc {

	// define walkFunc
	var walkFunc filepath.WalkFunc = func(path string, info os.FileInfo, err error) error {
		c := lookupDot(tar, toSlash(path))
		c.Tag(info)
		return nil
	}
	return walkFunc
}

func dirInfoWF(tar Dot, myName string) filepath.WalkFunc {

	// define walkFunc
	var walkFunc filepath.WalkFunc = func(path string, info os.FileInfo, err error) error {
	myName := "dirInfoWF"
		if tar.SeeError(myName, path, err) {
			return nil
		}
		if info.IsDir() {
			c := lookupDot(tar, toSlash(path))
			c.Tag(info)
		}
		return nil
	}
	return walkFunc
}

/*
Walk walks the file tree rooted at root, calling walkFn for each file or
directory in the tree, including root. All errors that arise visiting files
and directories are filtered by walkFn. The files are walked in lexical
order, which makes the output deterministic but means that for very large
directories Walk can be inefficient. Walk does not follow symbolic links.
*/

// Walk down path from d.K and add results below FileInfo: Key = FilePath, Val = os.FileInfo
//
// Must be called from type-node! (d.K == FilePath.Id)
func FileInfoWalk(tar Dot, path string) Dot {
	myName := "Walk"

	arg := frSlash(path) // path to walk

	to := lookupDot(tar, myName+":")
	to.UnlockedAdd(Path.Id(), toSlash(arg))
	c := lookupDot(to, FileInfo.Id()) // where to add
	filepath.Walk(arg, allInfoWF(c, myName))

	return tar
}

func DoFileInfoWalk(src, tar Dot) Dot {
	FileInfoWalk(tar, src.String())
	return src
}

func ExecFileInfoWalk(d Dot) Dot {
	FileInfoWalk(d, d.String())
	return d
}

func DirsInfoWalk(tar Dot, path string) Dot {
	myName := "DirsInfoWalk"

	arg := frSlash(path) // path to walk

	to := lookupDot(tar, myName+":")
	to.UnlockedAdd(Dirs.Id(), toSlash(arg))
	c := lookupDot(to, FileInfo.Id()) // where to add
	filepath.Walk(arg, dirInfoWF(c, myName))

	return tar
}

func DoDirsInfoWalk(src, tar Dot) Dot {
	DirsInfoWalk(tar, src.String())
	return src
}

func ExecDirsInfoWalk(d Dot) Dot {
	DirsInfoWalk(d, d.String())
	return d
}

/*
filepath.Dir(x) (path string)             // path is x less Base(), and cleaned
filepath.Base(x) string                   // base is last element of x, and cleaned
filepath.Join(filepath.Dir(x), filepath.Base(x)) = filepath.Clean(x)
filepath.Ext(x)                           // includes the .dot
filepath.Split(x) (dir, file string)      // x = dir+file, dir may be empty
filepath.Clean(x) (path string)

filepath.SplitList(x) []string            // only filepath . good for PATH or GOPATH

*/
