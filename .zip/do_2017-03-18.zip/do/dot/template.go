﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"bytes"

	"do/ats"
	"do/dot/funcs"
	ds "do/strings"
	"text/template"
)

type TemplateFriendly interface {
	Lock()   // via sync.Mutex
	Unlock() // via sync.Mutex
}

// var _ TemplateFriendly = New("Interface satisfied? :-)")

var _ = template.New("Don't cry!")
var _ = funcs.Funcs //Don't cry!

// MetaParse parses the comments as template and Tag's it into "Meta:"/Name()
func MetaParse(tar Dot, name, data string) Dot {
	myName := "MetaParse"

	tc, err := ds.Extract(data, commL, commR)
	if tar.SeeError(myName+"Extract", name, err) {
		return tar
	}

	ct, err := template.New(name).Funcs(funcs.Funcs).Delims(tmplL, tmplR).Parse(tc)
	if tar.SeeError(myName, name, err) {
		return tar
	}

	to := lookupDot(tar, Meta.Id())
	to = lookupDot(to, ct.Name())
	to.Tag(ct)
	return tar
}

func DoMetaParse(src, tar Dot) Dot {
	MetaParse(tar, src.String(), ats.GetString(src.GetV()))
	return src
}

func ExecMetaParse(d Dot) Dot {
	MetaParse(d, d.String(), ats.GetString(d.GetV()))
	return d
}

// TmplParse parses the data as template and Tag's it into "Tmpl:"/Name()
func TmplParse(tar Dot, name, data string) Dot {
	myName := "TmplParse"

	ct, err := template.New(name).Funcs(funcs.Funcs).Delims(tmplL, tmplR).Parse(data)
	if tar.SeeError(myName, name, err) {
		return tar
	}

	to := lookupDot(tar, Tmpl.Id())
	to = lookupDot(to, ct.Name())
	to.Tag(ct)
	return tar
}

func DoTmplParse(src, tar Dot) Dot {
	TmplParse(tar, src.String(), ats.GetString(src.GetV()))
	return src
}

func ExecTmplParse(d Dot) Dot {
	TmplParse(d, d.String(), ats.GetString(d.GetV()))
	return d
}

// Execute ===============================================

func TmplExecute(tar, data Dot, val interface{}) Dot {
	myName := "TmplExecute"

	var tmpl *template.Template
	switch t := val.(type) {
	case *template.Template:
		tmpl = t
	default:
		tar.SeeNotOk(myName, ats.GetString(val), false, "Value is not a Template")
		return tar
	}
	var buf bytes.Buffer
	err := tmpl.Execute(&buf, data)
	if tar.SeeError(myName, tmpl.Name(), err) {
		return tar
	}
	txt := string(buf.Bytes())

	to := lookupDot(tar, Tmpl.Id())
	to = lookupDot(to, tmpl.Name())
	to.Tag(txt)

	return tar
}

func DoTmplExecute(src, tar Dot) Dot {
	TmplExecute(tar, src, src.GetV())
	return src
}

func ExecTmplExecute(d Dot) Dot {
	TmplExecute(d, d, d.GetV())
	return d
}

/*
	if ct, err := ct.Parse(tc); err == nil {
		//fmt.Println(t)
		fmt.Println("Meta:")
		ct.Execute(os.Stdout, d)
	} else {
		fmt.Println(err)
	}
	_ = ct



	if t, err := t.Parse(tt); err == nil {
		//fmt.Println(t)
		fmt.Println("Tmpl:")
		t.Execute(os.Stdout, d)
	} else {
		fmt.Println(err)
	}
	_ = t

*/
