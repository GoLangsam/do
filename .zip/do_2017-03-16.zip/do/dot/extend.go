﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

type userFriendly interface {
	AddStrings(d Dot, key string, val ...string)         // adds key to d, and adds variadic strings below key
	AddStringS(d Dot, key string, val ...[]string)       // adds key to d, and adds slices below key
	AddMap(d Dot, key string, vals ...map[string]string) // adds key to d, and adds map(s) below key
}

// var _ userFriendly = New("Interface satisfied? :-)")

// Creators - as concurrency safe as Dot :-)

// AddStrings adds key to d, and adds variadic strings below key
func AddStrings(d Dot, key string, val ...string) {
	d.UnlockedAdd(key, val...)   // fullfill the promise
}

// AddStringS adds key to d, and adds slices below key
func AddStringS(d Dot, key string, val ...[]string) {
	for _, vs := range val {
		d.UnlockedAdd(key, vs...)   // fullfill the promise
	}
}

// AddMap adds key to d, and adds map(s) below key
func AddMap(d Dot, key string, val ...map[string]string) {
	for _, vs := range val {
		for k, v := range vs {
			c := lookup(d, k)
			_ = lookup(c, v)
		}
	}
}
