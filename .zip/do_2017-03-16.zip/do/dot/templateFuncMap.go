﻿// Copyright 2011 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package dot

import (
	"os"
	"runtime"
	"text/template"
)

// Null - return empty string - useful to pipe method-results away
func Null() interface{} {
	return ""
}

// os.Args as TempFunc "CmdLine"
func CmdLine() interface{} {
	return os.Args
}

// os.Environ as TempFunc - use range on it, as it returns a slice
func Environ() interface{} {
	return os.Environ()
}

// os.TempDir as TempFunc
func TempDir() interface{} {
	return os.TempDir()
}

// os.Getwd as TempFunc - silent on error
func Getwd() interface{} {
	wd, err := os.Getwd()
	if err != nil {
		return ""
	} else {
		return wd
	}
}

// os.Hostname as TempFunc - silent on error
func Hostname() interface{} {
	hn, err := os.Hostname()
	if err != nil {
		return ""
	} else {
		return hn
	}
}

// runtime.MemStats as TempFunc - reRead on each call
func MemStats() interface{} {
	stats := new(runtime.MemStats)
	runtime.ReadMemStats(stats)
	return *stats
}

var funcs = template.FuncMap{
	"null":     Null,
	"memstats": MemStats,
	"cmdline":  CmdLine,
	"getwd":    Getwd,
	"hostname": Hostname,
	"environ":  Environ,
	"tempdir":  TempDir,
}
