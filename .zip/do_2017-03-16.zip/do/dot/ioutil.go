﻿package dot

import (
	"io/ioutil"
	"os"
	"path/filepath"
)

var Perm os.FileMode = 0644 // default os.FileMode

// func ioutil.ReadFile(filename string) ([]byte, error)
func SetReadFile(d Dot) Dot {
	myName := "SetReadFile"

	filename := filepath.FromSlash(d.String())
	data, err := ioutil.ReadFile(filename)

	if !d.SeeError(myName, d.String(), err) {
		d.Tag(string(data))
	}
	return d
}

// func ioutil.WriteFile(filename string, data []byte, perm os.FileMode) error
func DoWriteFile(d Dot) Dot {
	myName := "DoWriteFile"

	value, ok := vtoNonEmptyString(d, myName) // is V a string?
	if !ok { return d }

	filename := filepath.FromSlash(d.String())
	data := []byte(value)

	err := ioutil.WriteFile(filename, data, Perm)
	_ = d.SeeError(myName, d.String(), err)
	return d
}

// func ioutil.ReadDir(dirname string) ([]os.FileInfo, error)
func AddReadDir(d Dot) Dot {
	myName := "AddReadDir"

	c := lookup(d, "ReadDir" + ":")

	dirname := filepath.FromSlash(d.String())

	dirs, err := ioutil.ReadDir(dirname)
	if d.SeeError(myName, d.String(), err) {
		return d
	}

	for _, d := range dirs {
		lookup(c, d.Name()).Tag(d)
	}
	return d
}

/*

func TempDir(dir, prefix string) (name string, err error)
func TempFile(dir, prefix string) (f *os.File, err error)
*/